
" variables {{{1

" }}}1

" highlight group {{{
hi default exTransparent gui=none guifg=background term=none cterm=none ctermfg=darkgray
hi default exCommentLable term=standout ctermfg=darkyellow ctermbg=Red gui=none guifg=lightgray guibg=red
"hi default exConfirmLine gui=none guibg=#ffe4b3 term=none cterm=none ctermbg=darkyellow
"hi default exTargetLine gui=none guibg=#ffe4b3 term=none cterm=none ctermbg=darkyellow
"hi default exConfirmLine gui=none  guibg=#f5b349 term=none cterm=none ctermbg=darkyellow
"hi default exTargetLine gui=none guibg=#f5b349 term=none cterm=none ctermbg=darkyellow
"hi default exConfirmLine gui=none  guibg=lightgreen term=none cterm=none ctermbg=darkyellow
"hi default exTargetLine gui=none guibg=lightgreen term=none cterm=none ctermbg=darkyellow
"hi default exConfirmLine gui=none  guibg=#b6b8b7 term=none cterm=none ctermbg=lightcyan
"hi default exTargetLine gui=none guibg=#b6b8b7 term=none cterm=none ctermbg=lightcyan
"hi default exConfirmLine gui=none  guibg=#6a6b6b term=none cterm=none ctermbg=lightcyan
"hi default exTargetLine gui=none guibg=#6a6b6b term=none cterm=none ctermbg=lightcyan
"hi default exConfirmLine gui=none  guibg=#bbbdbc term=none cterm=none ctermbg=lightcyan
"hi default exTargetLine gui=none guibg=#bbbdbc term=none cterm=none ctermbg=lightcyan
"hi default exConfirmLine gui=none  guifg=#f2c111 term=italic cterm=none ctermbg=lightcyan
"hi default exTargetLine gui=none guifg=#f2c111 term=italic cterm=none ctermbg=lightcyan
"hi default exConfirmLine gui=none  guifg=#37f211 term=bold,underline,italic cterm=none ctermbg=lightcyan
"hi default exTargetLine gui=none guifg=#37f211 term=bold,underline,italic cterm=none ctermbg=lightcyan
hi default exConfirmLine gui=none  guifg=#00ff00 term=bold,underline,italic cterm=none ctermbg=lightcyan
hi default exTargetLine gui=none guifg=#00ff00 term=bold,underline,italic cterm=none ctermbg=lightcyan
" }}}

" commands {{{1
command! EXbn call ex#buffer#navigate('bn')
command! EXbp call ex#buffer#navigate('bp')
command! EXbalt call ex#buffer#to_alternate_edit_buf()
command! EXbd call ex#buffer#keep_window_bd()

command! EXsw call ex#window#switch_window()
command! EXgp call ex#window#goto_plugin_window()

command! EXplugins call ex#echo_registered_plugins()
" }}}1

" autocmd {{{1
augroup ex_utility
    au!
    au VimEnter,WinLeave * call ex#window#record()
    au BufLeave * call ex#buffer#record()
augroup END
" }}}1

" ex#register_plugin register plugins {{{
" register Vim builtin window
call ex#register_plugin( 'help', { 'buftype': 'help' } )
call ex#register_plugin( 'qf', { 'buftype': 'quickfix' } )
" }}}

" vim:ts=4:sw=4:sts=4 et fdm=marker:
